import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class bouncing_ball_functions extends PApplet {

int ballX;
int ballY;

int speedX;
int speedY;

int foodX;
int foodY;
int score;

boolean isAlive;

public void setup() {
  
  //fullScreen();
  ballX = 50;
  ballY = 50;
  speedX = 5;
  speedY = 5;
  foodX = PApplet.parseInt(random(0, width));
  foodY = PApplet.parseInt(random(0, height));
  score = 0;

  isAlive = true;
}

public void draw() {
  background(255);

  if (isAlive) {
    eat();  
    die();
    bounce();
    display();
  } else {
    fill(0);
    textAlign(CENTER);
    textSize(80);
    text("GAMEOVER", width/2, height/2 -20);
    fill(0);
    textSize(30);
    text("Score: " + score, width/2, height/2 + 50);
  }
}

public void mouseClicked(){
  //reset
  speedX = 5;
  speedY = 5;
  foodX = PApplet.parseInt(random(0, width));
  foodY = PApplet.parseInt(random(0, height));
  score = 0;
  isAlive = true;
}
//CTRL + T


public void die() {
  //die umri
  float d = dist(ballX, ballY, mouseX, mouseY);
  if (  d   <   50/2 + 50/2) {
    //zastavit!!! 
    isAlive = false;
  } else {
    //pohybovat dal
    move();
  }
  
  if (score > 5) { 
      //todo
    }
}

public void eat() {
  //eat food
  float d = dist(foodX, foodY, mouseX, mouseY);
  if (  d   <   50/2 + 50/2) {
    //papej jidlo
    score++; //score = score +1;
    foodX = PApplet.parseInt(random(0, 640));
    foodY = PApplet.parseInt(random(0, 320));
  } else {
    //nic nedelame no
  }
}

public void move() {
  ballX += speedX * (score+1) * 0.1f;
  ballY += speedY * (score+1) * 0.1f;
  
  if (score > 5) { 
      //todo
    }
}

public void bounce() {
  if (ballX > width || ballX < 0) {
    speedX *= -1;
  }

  if (ballY > height || ballY < 0) {
    speedY *= -1;
  }
  
  if (score > 5) { 
      //todo
  }
}

public void display() {
  fill(250, 0, 0); //mic
  circle(ballX, ballY, 50);
  
  if (score > 5) { 
      //todo
  }

  fill(0, 255, 0); //myska
  ellipse(mouseX, mouseY, 50, 50);

  fill(0, 255, 255); //jidlo
  ellipse(foodX, foodY, 50, 50);

  fill(0);
  textSize(20);
  textAlign(CORNER);
  text("Score: " + score, 10, 30);
}
  public void settings() {  size(1000, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "bouncing_ball_functions" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
